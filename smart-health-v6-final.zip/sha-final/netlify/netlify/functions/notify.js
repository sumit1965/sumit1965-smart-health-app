// Netlify serverless function — auto-sends WhatsApp/SMS via Twilio
// No frontend click needed. Called automatically by the app on every medication event.
//
// Setup (one-time):
// 1. Go to netlify.com → your site → Site settings → Environment variables
// 2. Add:  TWILIO_ACCOUNT_SID   (from console.twilio.com)
//          TWILIO_AUTH_TOKEN    (from console.twilio.com)
//          TWILIO_FROM_NUMBER   (your Twilio WhatsApp sandbox: whatsapp:+14155238886)
//                               OR your Twilio phone number for SMS: +1XXXXXXXXXX

exports.handler = async (event) => {
  // CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
      },
      body: '',
    };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method not allowed' };
  }

  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return { statusCode: 400, body: 'Invalid JSON' };
  }

  const { to, message, channel = 'whatsapp' } = body;

  if (!to || !message) {
    return {
      statusCode: 400,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ error: 'Missing "to" or "message"' }),
    };
  }

  const accountSid = process.env.TWILIO_ACCOUNT_SID;
  const authToken  = process.env.TWILIO_AUTH_TOKEN;
  const fromRaw    = process.env.TWILIO_FROM_NUMBER;

  if (!accountSid || !authToken || !fromRaw) {
    return {
      statusCode: 500,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ error: 'Twilio env vars not configured. See README.' }),
    };
  }

  // Format numbers
  const cleanTo   = to.replace(/\D/g, '');
  const cleanFrom = fromRaw.replace(/[^\d+]/g, '');

  const from = channel === 'whatsapp' ? `whatsapp:+${cleanFrom.replace(/^\+/, '')}` : `+${cleanFrom.replace(/^\+/, '')}`;
  const toNum = channel === 'whatsapp' ? `whatsapp:+${cleanTo}` : `+${cleanTo}`;

  // Call Twilio REST API
  const twilioUrl = `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`;
  const credentials = Buffer.from(`${accountSid}:${authToken}`).toString('base64');

  const params = new URLSearchParams({ From: from, To: toNum, Body: message });

  try {
    const resp = await fetch(twilioUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: params.toString(),
    });

    const result = await resp.json();

    if (!resp.ok) {
      console.error('Twilio error:', result);
      return {
        statusCode: resp.status,
        headers: { 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify({ error: result.message || 'Twilio error', code: result.code }),
      };
    }

    return {
      statusCode: 200,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ success: true, sid: result.sid }),
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ error: err.message }),
    };
  }
};
